<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Ventas Finalizadas</h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-sm btn-primary">Registrar Venta</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="">
                        <table class="table">
                            <thead>
                                <th data-toggle="tooltip" data-placement="bottom" title="Fecha de Inicio / Fecha de Finalización">Fechas I/F</th>
                                <th>Cliente</th>
                                <th>Productos</th>
                                <th>Monto</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$sale->finalized_at): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                    <tr>
                                        <td><?php echo e(date('d-m-y', strtotime($sale->created_at))); ?><br><?php echo e(date('d-m-y', strtotime($sale->created_at))); ?></td>
                                        <td><a href="<?php echo e(route('clients.show', $sale->client)); ?>"><?php echo e($sale->client->name); ?><br><?php echo e($sale->client->document_type); ?>-<?php echo e($sale->client->document_id); ?></a></td>
                                        <td><?php echo e($sale->products->sum('qty')); ?></td>
                                        <td><?php echo e($sale->transactions->sum('amount')); ?>$</td>
                                        <td class="td-actions text-right">
                                            <a href="<?php echo e(route('sales.show', ['sale' => $sale])); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Ver Venta">
                                                <i class="tim-icons icon-zoom-split"></i>
                                            </a>
                                            <form action="<?php echo e(route('sales.destroy', $sale)); ?>" method="post" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="button" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Eliminar Venta" onclick="confirm('Estás seguro que quieres eliminar esta venta? Todos sus registros serán eliminados permanentemente.') ? this.parentElement.submit() : ''">
                                                    <i class="tim-icons icon-simple-remove"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        <?php echo e($sales->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                        <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Ventas Pendientes</h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-sm btn-primary">Registrar Venta</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Productos</th>
                            <th data-toggle="tooltip" data-placement="bottom" title="Monto Pagado / Monto Total">Monto P/T</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $unfinishedSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($sale->finalized_at): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                <tr>
                                    <td><?php echo e(date('d-m-y', strtotime($sale->created_at))); ?></td>
                                    <td><a href="<?php echo e(route('clients.show', $sale->client)); ?>"><?php echo e($sale->client->name); ?><br><?php echo e($sale->client->document_type); ?>-<?php echo e($sale->client->document_id); ?></a></td>
                                    <td><?php echo e($sale->products->count()); ?></td>
                                    <td ><?php echo e($sale->transactions->sum('amount')); ?>$ / <?php echo e($sale->products->sum('total_amount')); ?>$</td>
                                    <td class="td-actions text-right">
                                        <a href="<?php echo e(route('sales.show', ['sale' => $sale])); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Editar Venta">
                                            <i class="tim-icons icon-pencil"></i>
                                        </a>
                                        <form action="<?php echo e(route('sales.destroy', $sale)); ?>" method="post" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="button" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Eliminar Venta" onclick="confirm('Estás seguro que quieres eliminar esta venta? Todos sus registros serán eliminados permanentemente.') ? this.parentElement.submit() : ''">
                                                <i class="tim-icons icon-simple-remove"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Ventas', 'pageSlug' => 'sales', 'section' => 'transactions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/sales/index.blade.php ENDPATH**/ ?>