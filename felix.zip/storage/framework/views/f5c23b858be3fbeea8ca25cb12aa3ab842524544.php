<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Transacciones</h4>
                        </div>
                        <div class="col-4 text-right">
                            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#transactionModal">
                                Nueva Transacción
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="">
                        <table class="table tablesorter " id="">
                            <thead class=" text-primary">
                                <th>Fecha</th>
                                <th>Tipo</th>
                                <th>Titulo</th>
                                <th>Método</th>
                                <th>Monto</th>
                                <th>Referencia</th>
                                <th>Cliente</th>
                                <th>Proveedor</th>
                                <th>Transferencia</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(date('d-m-y', strtotime($transaction->created_at))); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('transactions.type', ['type' => $transaction->type])); ?>"><?php echo e($transactionname[$transaction->type]); ?></a>
                                        </td>
                                        <td style="max-width:150px"><?php echo e($transaction->title); ?></td>
                                        <td><a href="<?php echo e(route('methods.show', $transaction->method)); ?>"><?php echo e($transaction->method->name); ?></a></td>
                                        <td><?php echo e($transaction->amount); ?>$</td>
                                        <td><?php echo e($transaction->reference); ?></td>
                                        <td>
                                            <?php if($transaction->client): ?>
                                                <a href="<?php echo e(route('clients.show', $transaction->client)); ?>"><?php echo e($transaction->client->name); ?><br><?php echo e($transaction->client->document_type); ?>-<?php echo e($transaction->client->document_id); ?></a>
                                            <?php else: ?>
                                                No Aplica
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($transaction->provider): ?>
                                                <a href="<?php echo e(route('providers.show', $transaction->provider)); ?>"><?php echo e($transaction->provider->name); ?></a>
                                            <?php else: ?>
                                                No Aplica
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($transaction->transfer): ?>
                                                <a href="<?php echo e(route('transfer.show', $transaction->transfer)); ?>">ID <?php echo e($transaction->transfer->id); ?></a>
                                            <?php else: ?>
                                                No Aplica
                                            <?php endif; ?>
                                        </td>
                                        <td class="td-actions text-right">
                                            <?php if($transaction->sale_id): ?>
                                                <a href="<?php echo e(route('sales.show', $transaction->sale)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Más Detalles">
                                                    <i class="tim-icons icon-zoom-split"></i>
                                                </a>
                                            <?php elseif($transaction->transfer_id): ?>
                                                <a href="<?php echo e(route('transfer.show', $transaction->transfer)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Más Detalles">
                                                    <i class="tim-icons icon-zoom-split"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('transactions.edit', $transaction)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Editar Transacción">
                                                    <i class="tim-icons icon-pencil"></i>
                                                </a>
                                                <form action="<?php echo e(route('transactions.destroy', $transaction)); ?>" method="post" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="button" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Eliminar Transacción" onclick="confirm('Estás seguro que quieres eliminar esta transacción? No quedará registro alguno.') ? this.parentElement.submit() : ''">
                                                        <i class="tim-icons icon-simple-remove"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        <?php echo e($transactions->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="transactionModal" tabindex="-1" role="dialog" aria-labelledby="transactionModal" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nueva Transacción</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(route('transactions.create', ['type' => 'payment'])); ?>" class="btn btn-sm btn-primary">Pago</a>
                        <a href="<?php echo e(route('transactions.create', ['type' => 'income'])); ?>" class="btn btn-sm btn-primary">Ingreso</a>
                        <a href="<?php echo e(route('transactions.create', ['type' => 'expense'])); ?>" class="btn btn-sm btn-primary">Gasto</a>
                        <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-sm btn-primary">Venta</a>
                        <a href="<?php echo e(route('transfer.create')); ?>" class="btn btn-sm btn-primary">Transferencia</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Transacciones', 'pageSlug' => 'transactions', 'section' => 'transactions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/transactions/index.blade.php ENDPATH**/ ?>