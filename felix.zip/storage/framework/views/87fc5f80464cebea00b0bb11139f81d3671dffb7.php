<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card card-tasks">
                <div class="card-header">
                    <h4 class="card-title">Estadísticas de Transacciones</h4>
                </div>
                <div class="card-body">
                    <div class="table-full-width table-responsive">
                        <table class="table">
                            <thead>
                                <th>Periodo</th>
                                <th>Transacciones</th>
                                <th>Ingresos</th>
                                <th>Egresos</th>
                                <th>Balance</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transactionsperiods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($period); ?></td>
                                        <td><?php echo e($data['transactions']); ?></td>
                                        <td><?php echo e($data['incomes']); ?>$</td>
                                        <td><?php echo e($data['expenses']); ?>$</td>
                                        <td><?php echo e($data['balance']); ?>$</td>
                                        <td></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-tasks">
                <div class="card-header">
                    <h4 class="card-title">Estadísticas por Método</h4>
                </div>
                <div class="card-body">
                    <div class="table-full-width table-responsive">
                        <table class="table">
                            <thead>
                                <th>Método</th>
                                <th>Transacciones <?php echo e($date->year); ?></th>
                                <th>Balance <?php echo e($date->year); ?></th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($method->name); ?></td>
                                        <td><?php echo e($yeartransactions->where('payment_method_id', $method->id)->count()); ?></td>
                                        <td><?php echo e($yeartransactions->where('payment_method_id', $method->id)->sum('amount')); ?>$</td>
                                        <td><?php echo e($method->name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Estadísticas de Ventas</h4>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <th>Periodo</th>
                        <th>Ventas</th>
                        <th>Clientes</th>
                        <th>Productos</th>
                        <th>Productos (Únicos)</th>
                        <th>Transacciones</th>
                        <th>Balance</th>
                        <th data-toggle="tooltip" data-placement="bottom" title="Promedio de ingresos por cada venta">Promedio C/V</th>
                        <th>Por Finalizar</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $salesperiods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($period); ?></td>
                                <td><?php echo e($info['sales']); ?></td>
                                <td><?php echo e($info['clients']); ?></td>
                                <td><?php echo e($info['products']); ?></td>
                                <td><?php echo e($info['uniqueproducts']); ?></td>
                                <td><?php echo e($info['transactions']); ?></td>
                                <td><?php echo e($info['balance']); ?>$</td>
                                <td><?php echo e(round($info['avg'], 2)); ?>$</td>
                                <td><?php echo e($info['unfinalized']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['pageSlug' => 'tstats', 'page' => 'Estadísticas', 'section' => 'transactions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/transactions/stats.blade.php ENDPATH**/ ?>