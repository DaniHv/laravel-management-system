<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Información del Producto</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Categoría</th>
                            <th>Nombre</th>
                            <th>Stock</th>
                            <th>Stock Defectuoso</th>
                            <th>Precio Base</th>
                            <th>Precio Promedio</th>
                            <th>Ventas Totales</th>
                            <th>Ingresos Producidos</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><a href="<?php echo e(route('categories.show', $product->category)); ?>"><?php echo e($product->category->name); ?></a></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->stock); ?></td>
                                <td><?php echo e($product->stock_defective); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e(round($product->solds->avg('price'), 2)); ?></td>
                                <td><?php echo e($product->solds->sum('qty')); ?></td>
                                <td><?php echo e($product->solds->sum('total_amount')); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Ventas Producidas: <?php echo e($product->solds->count()); ?></h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>Fecha</th>
                            <th>ID de Venta</th>
                            <th>Cantidad</th>
                            <th>Precio Unidad</th>
                            <th>Monto Total</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sold): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('d-m-y', strtotime($sold->created_at))); ?></td>
                                    <td><a href="<?php echo e(route('sales.show', $sold->sale)); ?>"><?php echo e($sold->sale_id); ?></a></td>
                                    <td><?php echo e($sold->qty); ?></td>
                                    <td><?php echo e($sold->price); ?></td>
                                    <td><?php echo e($sold->total_amount); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end">
                        <?php echo e($solds->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Información de Producto', 'pageSlug' => 'products', 'section' => 'inventory'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/inventory/products/show.blade.php ENDPATH**/ ?>