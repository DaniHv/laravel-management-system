<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Clientes</h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-sm btn-primary">Añadir cliente</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="">
                        <table class="table tablesorter " id="">
                            <thead class=" text-primary">
                                <th scope="col">Nombre</th>
                                <th scope="col">Documento</th>
                                <th scope="col">Email</th>
                                <th scope="col">Teléfono</th>
                                <th scope="col">Compras</th>
                                <th scope="col">Total Pagado</th>
                                <th scope="col">Última Compra</th>
                                <th scope="col"></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->name); ?></td>
                                        <td><?php echo e($client->document_type); ?>-<?php echo e($client->document_id); ?></td>
                                        <td>
                                            <a href="mailto:<?php echo e($client->email); ?>"><?php echo e($client->email); ?></a>
                                        </td>
                                        <td><?php echo e($client->phone); ?></td>
                                        <td><?php echo e($client->sales->count()); ?></td>
                                        <td><?php echo e($client->transactions->sum('amount')); ?>$</td>
                                        <td><?php echo e(($client->sales->sortByDesc('created_at')->first()) ? date('d-m-y', strtotime($client->sales->sortByDesc('created_at')->first()->created_at)) : 'NUNCA'); ?></td>
                                        <td class="td-actions text-right">
                                            <a href="<?php echo e(route('clients.show', $client)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Más Detalles">
                                                <i class="tim-icons icon-zoom-split"></i>
                                            </a>
                                            <a href="<?php echo e(route('clients.edit', $client)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Editar Cliente">
                                                <i class="tim-icons icon-pencil"></i>
                                            </a>
                                            <form action="<?php echo e(route('clients.destroy', $client)); ?>" method="post" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="button" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Eliminar Cliente" onclick="confirm('Estás seguro que quieres eliminar a este cliente? Los registros de sus compras y transacciones no serán eliminados.') ? this.parentElement.submit() : ''">
                                                    <i class="tim-icons icon-simple-remove"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        <?php echo e($clients->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Clientes', 'pageSlug' => 'clients', 'section' => 'clients'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/clients/index.blade.php ENDPATH**/ ?>