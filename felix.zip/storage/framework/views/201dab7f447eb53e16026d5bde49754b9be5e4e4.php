<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Información del Método</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Transacciones</th>
                            <th>Balance Diario</th>
                            <th>Balance Semanal</th>
                            <th>Balance Trimestral</th>
                            <th>Balance Mensual</th>
                            <th>Balance Anual</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($method->id); ?></td>
                                <td><?php echo e($method->name); ?></td>
                                <td><?php echo e($method->description); ?></td>
                                <td><?php echo e($method->transactions->count()); ?></td>
                                <td><?php echo e($balances['daily']); ?>$</td>
                                <td><?php echo e($balances['weekly']); ?>$</td>
                                <td><?php echo e($balances['quarter']); ?>$</td>
                                <td><?php echo e($balances['monthly']); ?>$</td>
                                <td><?php echo e($balances['annual']); ?>$</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Transacciones: <?php echo e($transactions->count()); ?></h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Tipo</th>
                            <th>Título</th>
                            <th>Monto</th>
                            <th>Referencia</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transaction->id); ?></td>
                                    <td><?php echo e(date('d-m-y', strtotime($transaction->created_at))); ?></td>
                                    <td><a href="<?php echo e(route('transactions.type', $transaction->type)); ?>"><?php echo e($transactionname[$transaction->type]); ?></a></td>
                                    <td><?php echo e($transaction->title); ?></td>
                                    <td><?php echo e($transaction->amount); ?>$</td>
                                    <td><?php echo e($transaction->reference); ?></td>
                                    <td class="td-actions text-right">
                                        <?php if($transaction->sale_id): ?>
                                            <a href="<?php echo e(route('sales.show', $transaction->sale)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Más Detalles">
                                                <i class="tim-icons icon-zoom-split"></i>
                                            </a>
                                        <?php elseif($transaction->transfer_id): ?>
                                            <a href="<?php echo e(route('sales.show', $transaction->sale)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Más Detalles">
                                                <i class="tim-icons icon-zoom-split"></i>
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('transactions.edit', $transaction)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Editar Transacción">
                                                <i class="tim-icons icon-pencil"></i>
                                            </a>
                                            <form action="<?php echo e(route('transactions.destroy', $transaction)); ?>" method="post" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="button" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Eliminar Transacción" onclick="confirm('Estás seguro que quieres eliminar esta transacción? No quedará registro alguno.') ? this.parentElement.submit() : ''">
                                                    <i class="tim-icons icon-simple-remove"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['page' => 'Información de Método', 'pageSlug' => 'methods', 'section' => 'methods'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/methods/show.blade.php ENDPATH**/ ?>