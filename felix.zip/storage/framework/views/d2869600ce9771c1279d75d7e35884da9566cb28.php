<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Información del Proveedor</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Información de Pago</th>
                            <th>Pagos Realizados</th>
                            <th>Total Pagado</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($provider->id); ?></td>
                                <td><?php echo e($provider->name); ?></td>
                                <td><?php echo e($provider->description); ?></td>
                                <td><?php echo e($provider->email); ?></td>
                                <td><?php echo e($provider->phone); ?></td>
                                <td style="max-width: 175px"><?php echo e($provider->paymentinfo); ?></td>
                                <td><?php echo e($provider->transactions->count()); ?></td>
                                <td><?php echo e(abs($provider->transactions->sum('amount'))); ?>$</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Pagos Realizados: <?php echo e($transactions->count()); ?></h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>Fecha</th>
                            <th>ID</th>
                            <th>Titulo</th>
                            <th>Método</th>
                            <th>Monto</th>
                            <th>Referencia</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('d-m-y', strtotime($transaction->created_at))); ?></td>
                                    <td><?php echo e($transaction->id); ?></td>
                                    <td><?php echo e($transaction->title); ?></td>
                                    <td><a href="<?php echo e(route('methods.show', $transaction->method)); ?>"><?php echo e($transaction->method->name); ?></a></td>
                                    <td><?php echo e($transaction->amount); ?>$</td>
                                    <td><?php echo e($transaction->reference); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end">
                        <?php echo e($transactions->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Información de Proveedor', 'pageSlug' => 'providers', 'section' => 'providers'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/providers/show.blade.php ENDPATH**/ ?>