<footer class="footer">
    <div class="container-fluid">
        <ul class="nav">
            <li class="nav-item">
                <a href="https://creative-tim.com" target="blank" class="nav-link">
                    dadada
                </a>
            </li>
            <li class="nav-item">
                <a href="https://updivision.com" target="blank" class="nav-link">
                    dadada
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    About Us
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    Blog
                </a>
            </li>
        </ul>
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <i class="tim-icons icon-heart-2"></i> 
            <a href="https://creative-tim.com" target="_blank"></a> &amp;
            <a href="https://updivision.com" target="_blank"></a>.
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\felix\resources\views/layouts/footer.blade.php ENDPATH**/ ?>