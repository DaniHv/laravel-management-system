<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Resumen de Venta</h4>
                        </div>
                        <?php if(!$sale->finalized_at): ?>
                            <div class="col-4 text-right">
                                <?php if(($sale->transactions->count() == 0) || ($sale->products->count() == 0)): ?>
                                    <form action="<?php echo e(route('sales.destroy', $sale)); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-sm btn-primary">
                                            Eliminar Venta
                                        </button>
                                    </form>
                                <?php elseif($sale->transactions->sum('amount') == $sale->products->sum('total_amount')): ?>
                                    <button type="button" class="btn btn-sm btn-primary" onclick="confirm('Confirmas querer finalizar esta venta? Sus registros no podrán ser modificados de ahora en más.') ? window.location.replace('<?php echo e(route('sales.finalize', $sale)); ?>') : ''">
                                        Finalizar Venta
                                    </button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-sm btn-primary" onclick="confirm('ATENCIÓN: Las transacciones de esta venda no parecen coincidir con el costo de los productos, seguro quieres finalizarla? Sus registros no podrán ser modificados de ahora en más.') ? window.location.replace('<?php echo e(route('sales.finalize', $sale)); ?>') : ''">
                                        Finalizar Venta
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Usuario</th>
                            <th>Cliente</th>
                            <th>Productos</th>
                            <th>Transacciones</th>
                            <th>Costo Total</th>
                            <th>Última Actualización</th>
                            <th>Status</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($sale->id); ?></td>
                                <td><?php echo e(date('d-m-y', strtotime($sale->created_at))); ?></td>
                                <td><?php echo e($sale->user->name); ?></td>
                                <td><a href="<?php echo e(route('clients.show', $sale->client)); ?>"><?php echo e($sale->client->name); ?><br><?php echo e($sale->client->document_type); ?>-<?php echo e($sale->client->document_id); ?></a></td>
                                <td><?php echo e($sale->products->sum('qty')); ?></td>
                                <td>
                                    <?php if($sale->transactions->sum('amount') < $sale->products->sum('total_amount')): ?>
                                        <span style="color:red;">
                                            <?php echo e($sale->transactions->count()); ?> - Total (<?php echo e($sale->transactions->sum('amount')); ?>$)
                                            <br>
                                            <?php echo e($sale->products->sum('total_amount') - $sale->transactions->sum('amount')); ?>$ Restantes
                                        </span>
                                    <?php elseif($sale->transactions->sum('amount') > $sale->products->sum('total_amount')): ?>
                                        <span style="color:orange;">
                                            <?php echo e($sale->transactions->count()); ?> - Total (<?php echo e($sale->transactions->sum('amount')); ?>$)
                                            <br>
                                            <?php echo e($sale->transactions->sum('amount') - $sale->products->sum('total_amount')); ?>$ Vuelto Restante
                                        </span>
                                    <?php else: ?>
                                        <span style="color:green;"><?php echo e($sale->transactions->count()); ?> - Total (<?php echo e($sale->transactions->sum('amount')); ?>$)</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($sale->transactions->sum('amount') < $sale->products->sum('total_amount')): ?>
                                        <span style="color:red;"><?php echo e($sale->products->sum('total_amount')); ?>$</span>
                                    <?php elseif($sale->transactions->sum('amount') > $sale->products->sum('total_amount')): ?>
                                        <span style="color:orange;"><?php echo e($sale->products->sum('total_amount')); ?>$</span>
                                    <?php else: ?>
                                        <span style="color:green;"><?php echo e($sale->products->sum('total_amount')); ?>$</span>
                                    <?php endif; ?>
                                    <br>
                                </td>
                                <td><?php echo e(date('d-m-y', strtotime($sale->updated_at))); ?></td>
                                <td><?php echo $sale->finalized_at ? 'Finalizado al<br>'.date('d-m-y', strtotime($sale->finalized_at)) : (($sale->transactions->sum('amount') == $sale->products->sum('total_amount')) ? 'POR FINALIZAR' : 'EN ESPERA'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card card-tasks">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Productos: <?php echo e($sale->products->sum('qty')); ?></h4>
                        </div>
                        <?php if(!$sale->finalized_at): ?>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(route('sales.product.add', ['sale' => $sale->id])); ?>" class="btn btn-sm btn-primary">Añadir</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-full-width table-responsive">
                        <table class="table table-sorter">
                            <thead>
                                <th>Categoría</th>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Total</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sold_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sold_product->product->category->name); ?></td>
                                        <td><?php echo e($sold_product->product->name); ?></td>
                                        <td><?php echo e($sold_product->qty); ?></td>
                                        <td><?php echo e($sold_product->total_amount); ?>$</td>
                                        <td class="td-actions text-right">
                                            <?php if(!$sale->finalized_at): ?>
                                                <a href="<?php echo e(route('sales.product.edit', ['sale' => $sale, 'soldproduct' => $sold_product])); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Editar Pedido">
                                                    <i class="tim-icons icon-pencil"></i>
                                                </a>
                                                <form action="<?php echo e(route('sales.product.destroy', ['sale' => $sale, 'soldproduct' => $sold_product])); ?>" method="post" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="button" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Eliminar Pedido" onclick="confirm('Estás seguro que quieres eliminar este pedido de producto/s? Su registro será eliminado de esta venta.') ? this.parentElement.submit() : ''">
                                                        <i class="tim-icons icon-simple-remove"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-tasks">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Transacciones: <?php echo e($sale->transactions->count()); ?></h4>
                        </div>
                        <?php if(!$sale->finalized_at): ?>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(route('sales.transaction.add', ['sale' => $sale->id])); ?>" class="btn btn-sm btn-primary">Añadir</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-full-width table-responsive">
                        <table class="table table-sorter">
                            <thead>
                                <th>Fecha</th>
                                <th>Tipo</th>
                                <th>Método</th>
                                <th>Monto</th>
                                <th>Referencia</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sale->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(date('d-m-y', strtotime($transaction->created_at))); ?></td>
                                        <td>
                                        <?php if($transaction->type == 'income'): ?>
                                            Pago
                                        <?php else: ?>
                                            Vuelto
                                        <?php endif; ?>
                                        </td>
                                        <td><?php echo e($transaction->method->name); ?></td>
                                        <td><?php echo e($transaction->amount); ?>$</td>
                                        <td><?php echo e($transaction->reference); ?></td>
                                        <td class="td-actions text-right">
                                            <?php if(!$sale->finalized_at): ?>
                                                <a href="<?php echo e(route('sales.transaction.edit', ['sale' => $sale, 'transaction' => $transaction])); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Editar Transacción">
                                                    <i class="tim-icons icon-pencil"></i>
                                                </a>
                                                <form action="<?php echo e(route('sales.transaction.destroy', ['sale' => $sale, 'transaction' => $transaction])); ?>" method="post" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="button" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Eliminar Transacción" onclick="confirm('Estás seguro que quieres eliminar esta transacción? Su registro será eliminado de esta venta.') ? this.parentElement.submit() : ''">
                                                        <i class="tim-icons icon-simple-remove"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets')); ?>/js/sweetalerts2.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['page' => 'Administrar Venta', 'pageSlug' => 'sales', 'section' => 'transactions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/sales/show.blade.php ENDPATH**/ ?>