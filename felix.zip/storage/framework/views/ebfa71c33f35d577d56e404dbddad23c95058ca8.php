<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Información del Cliente</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Documento</th>
                            <th>Teléfono</th>
                            <th>Email</th>
                            <th>Compras</th>
                            <th>Última Compra</th>
                            <th>Total Pagado</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($client->id); ?></td>
                                <td><?php echo e($client->name); ?></td>
                                <td><?php echo e($client->document_type); ?>-<?php echo e($client->document_id); ?></td>
                                <td><?php echo e($client->phone); ?></td>
                                <td><?php echo e($client->email); ?></td>
                                <td><?php echo e($client->sales->count()); ?></td>
                                <td><?php echo e(date('d-m-y', strtotime($sales->first()->created_at))); ?></td>
                                <td><?php echo e($client->transactions->sum('amount')); ?>$</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Compras: <?php echo e($sales->count()); ?></h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Productos</th>
                            <th>Monto</th>
                            <th>Pagado</th>
                            <th>Transacciones</th>
                            <th>Estado</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('sales.show', $sale)); ?>"><?php echo e($sale->id); ?></a></td>
                                    <td><?php echo e(date('d-m-y', strtotime($sale->created_at))); ?></td>
                                    <td><?php echo e($sale->products->sum('qty')); ?></td>
                                    <td><?php echo e($sale->products->sum('total_amount')); ?></td>
                                    <td><?php echo e($sale->transactions->sum('amount')); ?></td>
                                    <td><?php echo e($sale->transactions->count()); ?></td>
                                    <td><?php echo e(($sale->finalized_at) ? 'FINALIZADA' : 'EN ESPERA'); ?></td>
                                    <td class="td-actions text-right">
                                        <a href="<?php echo e(route('sales.show', $sale)); ?>" class="btn btn-link" data-toggle="tooltip" data-placement="bottom" title="Más Detalles">
                                            <i class="tim-icons icon-zoom-split"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end">
                        <?php echo e($sales->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['page' => 'Información de Cliente', 'pageSlug' => 'clients', 'section' => 'clients'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/clients/show.blade.php ENDPATH**/ ?>