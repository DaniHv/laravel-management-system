<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title">Gastos</h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-sm btn-primary">Nuevo Gasto</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="">
                        <table class="table tablesorter " id="">
                            <thead class=" text-primary">
                                <th scope="col">Fecha</th>
                                <th scope="col">Titulo</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Método</th>
                                <th scope="col">Monto</th>
                                <th scope="col"></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e(date('d-m-y', strtotime($expense->created_at))); ?></td>
                                        <td> <?php echo e($expense->title); ?></td>
                                        <td> <?php echo e($expense->description); ?></td>
                                        <td> <?php echo e($expense->method->name); ?></td>
                                        <td> <?php echo e($expense->amount); ?></td>
                                        <td></td>
                                        <td class="text-right">
                                                <div class="dropdown">
                                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="tim-icons icon-bullet-list-67"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                        <form action="<?php echo e(route('expenses.destroy', $expense)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>

                                                            <a class="dropdown-item" href="<?php echo e(route('expenses.edit', $expense)); ?>">Editar</a>
                                                            <button type="button" class="dropdown-item" onclick="confirm('Estás seguro que quieres eliminar los datos de este proveedor?, los pagos realizados a él se marcarán como pago a proovedor eliminado') ? this.parentElement.submit() : ''">
                                                                        Eliminar
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        <?php echo e($expenses->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => 'Gastos', 'pageSlug' => 'expenses-list', 'section' => 'transactions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\felix\resources\views/expenses/index.blade.php ENDPATH**/ ?>